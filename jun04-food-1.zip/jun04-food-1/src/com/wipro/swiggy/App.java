package com.wipro.swiggy;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.wipro.swiggy.model.Food;
import com.wipro.swiggy.model.FoodDaoImpl;

public class App {

	public static void main(String[] args) {
		
		Food food=new Food(null, "Paratta", "Dinner", 15.0f);
		
		ClassPathXmlApplicationContext ctx=new ClassPathXmlApplicationContext("bean.xml");
		FoodDaoImpl fdao=(FoodDaoImpl) ctx.getBean("fdao");
		fdao.create(food);
		
		
		System.out.println("Hello world");
	}

}
